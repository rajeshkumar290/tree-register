# 🌳 Tree Plantation Register

A beginner-friendly, menu-driven Python app for recording planted trees, their locations and follow-up survival checks.
Built for *Python for Good — Project #46*. Standard library only, plus optional Matplotlib for charts.

## Quick start

```bash
cd tree_register
python -m venv .venv && source .venv/bin/activate      # Windows: .venv\Scripts\activate
pip install -r requirements.txt                          # only needed for charts
python main.py
```

On first launch the register is empty and the app offers to load **41 sample records** — say `y` for the demo.
Use `python main.py --data-dir some/folder` to keep a separate register.

## Features

| Brief requirement | Where |
|---|---|
| Interactive terminal menu | `main.py` (12 options, ANSI colour, auto-disabled when piped / `NO_COLOR` set) |
| Defensive input validation | `validation.py` — every prompt loops until valid; type `cancel` to back out |
| Core logic (plantings, locations, survival checks) | `models.py` |
| JSON persistence | `storage.py` — saved after every change, atomic writes |
| Search & filter | keyword (all fields incl. notes), species, location, status |
| Executive summary | totals, survival rate, by species / location, monthly trend, key trends (`analytics.py`) |
| Matplotlib charts | `plots.py` → planting trend, survival by species, status distribution (PNG) |
| Multi-format export | Markdown summary, plain-text audit log, CSV (`exports.py`) |
| Threshold warnings | overdue checks, <50 % survival, total loss, anomalies (`analytics.py`) |
| Bulk CSV import | `importer.py` — row-by-row error log, duplicate detection |

## How records work

One record = one planting batch: species, location, date, quantity, planted-by, notes, and a list of dated **survival checks** (how many saplings are still alive).

| Rule | Value (change in `models.py`) |
|---|---|
| Quantity per record | 1 – 1000 |
| Planting / check dates | not in the future; a check can't predate planting or the previous check |
| Surviving count | 0 – last known survivors (a count can't go *up*) |
| First check due | 30 days after planting |
| Later checks due | every 90 days |
| Status | **Thriving** ≥ 80 % · **Fair** 50–79 % · **At Risk** < 50 % · **Lost** 0 alive · **Unchecked** no checks yet |

Survival rates only count records that have at least one check, so unchecked plantings don't drag the average down.

## Warnings

* **CRITICAL** — At Risk (<50 %) or Lost
* **WARNING** — a first/follow-up check is overdue
* **ANOMALY** — future dates, checks before planting, survivors that increase between checks, unusually large batches (≥ 500)

A count of urgent items is shown on startup.

## CSV import

Required columns: `species, location, planted_on, quantity`.
Optional: `planted_by, notes, last_check_date, surviving` (the last two must come together).
Aliases such as `planted_date`, `qty`, `alive` are understood. Dates: `YYYY-MM-DD`, `DD-MM-YYYY` or `DD/MM/YYYY`.

Bad rows are skipped, never fatal; each one is logged with its line number to `data/exports/import_errors_<time>.log`.
Try it: menu **10** → `sample_data/legacy_with_errors.csv` (2 rows import, 7 are rejected with reasons).
CSV exports use a superset of these columns, so exports can be re-imported.

## Project layout

```
main.py            menu loop and handlers
models.py          Tree / Check dataclasses, status + due-date rules, constants
validation.py      pure parsers + interactive prompt wrappers
storage.py         JSON load/save, corruption recovery, id generation
analytics.py       filtering, warnings, summary aggregation
plots.py           Matplotlib charts (lazy import → app works without it)
exports.py         Markdown / audit-log / CSV writers
importer.py        CSV bulk import
ui.py              colours, tables, pagination
sample_data/       sample_trees.json / .csv, legacy_with_errors.csv
tools/make_sample_data.py   regenerates the samples (dates relative to today)
tests/test_core.py          unit tests
data/              created at runtime: trees.json and exports/
```

## Robustness

* **Missing data file** → created automatically.
* **Corrupt / unreadable JSON** → renamed to `trees.json.corrupt-<time>` and a clean register starts; nothing is silently overwritten.
* **Individually invalid records** → skipped with a startup notice; the rest load.
* **Crash-safe saves** → written to a temp file, then atomically swapped in.
* **Blank / non-numeric / out-of-range input** → re-prompted, never a crash. Ctrl-C or closed input exits cleanly.
* **Matplotlib missing** → charts option reports it; everything else works.

## Suggested 5-minute demo

1. `python main.py` → load sample data; note the "⚠ need attention" banner.
2. **1** Record a planting — deliberately enter a blank species, a future date, `abc` and `99999` as quantity; watch each get rejected.
3. **2** Log a check for the new record; try a count higher than planted.
4. **4** Search `neem`; **7** Warnings; **6** Executive summary.
5. **8** Generate charts → open the PNGs in `data/exports/charts/`.
6. **9** Export all → open the Markdown summary.
7. **10** Import `sample_data/legacy_with_errors.csv` → show the error log.
8. **0** Exit, relaunch → the new record is still there (persistence).

## Tests

```bash
python -m unittest discover -s tests -v
```
