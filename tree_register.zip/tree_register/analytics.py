"""Filtering, warning detection and executive-summary aggregation."""
from __future__ import annotations

from collections import defaultdict
from datetime import date, timedelta

from models import AT_RISK_PCT, CHECK_INTERVAL_DAYS, Tree
from ui import bar, format_table

LARGE_BATCH = 500    # batches this big get flagged for a sanity check


# ---- search / filter ---------------------------------------------------------
def filter_trees(trees: list[Tree], keyword: str | None = None, species: str | None = None,
                 location: str | None = None, status: str | None = None) -> list[Tree]:
    kw = keyword.casefold() if keyword else None
    sp = species.casefold() if species else None
    lo = location.casefold() if location else None
    result = []
    for t in trees:
        if kw and kw not in " ".join([t.tree_id, t.species, t.location, t.planted_by, t.notes,
                                      *(c.notes for c in t.checks)]).casefold():
            continue
        if sp and sp not in t.species.casefold():
            continue
        if lo and lo not in t.location.casefold():
            continue
        if status and t.status != status:
            continue
        result.append(t)
    return result


# ---- warnings ----------------------------------------------------------------
def find_warnings(trees: list[Tree], today: date) -> list[tuple[str, str, str]]:
    """Returns (level, tree_id, message). Level is 'CRITICAL', 'WARNING' or 'ANOMALY'."""
    out: list[tuple[str, str, str]] = []
    for t in trees:
        due = t.next_check_due
        if due and due < today:
            kind = "first check" if not t.checks else "follow-up check"
            out.append(("WARNING", t.tree_id, f"{kind} overdue by {(today - due).days} days (was due {due})"))
        if t.status == "Lost":
            out.append(("CRITICAL", t.tree_id, f"all {t.quantity} saplings lost ({t.species}, {t.location})"))
        elif t.status == "At Risk":
            out.append(("CRITICAL", t.tree_id, f"survival only {t.survival_pct:.0f}% (below {AT_RISK_PCT:.0f}%)"))
        if t.planted_on > today:
            out.append(("ANOMALY", t.tree_id, f"planting date {t.planted_on} is in the future"))
        if t.quantity >= LARGE_BATCH:
            out.append(("ANOMALY", t.tree_id, f"unusually large batch of {t.quantity} saplings - verify count"))
        previous = None
        for c in t.checks:
            if c.checked_on < t.planted_on:
                out.append(("ANOMALY", t.tree_id, f"check on {c.checked_on} is before planting"))
            if c.checked_on > today:
                out.append(("ANOMALY", t.tree_id, f"check on {c.checked_on} is in the future"))
            if previous is not None and c.surviving > previous.surviving:
                out.append(("ANOMALY", t.tree_id,
                            f"survivors rose from {previous.surviving} to {c.surviving} on {c.checked_on}"))
            previous = c
    order = {"CRITICAL": 0, "WARNING": 1, "ANOMALY": 2}
    out.sort(key=lambda w: (order[w[0]], w[1]))
    return out


# ---- aggregation -------------------------------------------------------------
def group_stats(trees: list[Tree], key) -> list[dict]:
    """Per-group totals. Survival % only counts records that have been checked."""
    groups: dict[str, list[Tree]] = defaultdict(list)
    for t in trees:
        groups[key(t)].append(t)
    rows = []
    for name, members in groups.items():
        checked = [t for t in members if t.checks]
        planted_checked = sum(t.quantity for t in checked)
        alive = sum(t.survivors or 0 for t in checked)
        rows.append({
            "name": name,
            "records": len(members),
            "planted": sum(t.quantity for t in members),
            "alive": alive if checked else None,
            "rate": 100.0 * alive / planted_checked if planted_checked else None,
        })
    rows.sort(key=lambda r: (-r["planted"], r["name"]))
    return rows


def monthly_planting(trees: list[Tree]) -> list[tuple[str, int]]:
    totals: dict[str, int] = defaultdict(int)
    for t in trees:
        totals[t.planted_on.strftime("%Y-%m")] += t.quantity
    return sorted(totals.items())


def summarize(trees: list[Tree], today: date) -> dict:
    checked = [t for t in trees if t.checks]
    planted_checked = sum(t.quantity for t in checked)
    alive = sum(t.survivors or 0 for t in checked)
    recent = sum(t.quantity for t in trees if today - timedelta(days=90) < t.planted_on <= today)
    prior = sum(t.quantity for t in trees if today - timedelta(days=180) < t.planted_on <= today - timedelta(days=90))
    status_counts = {s: 0 for s in ("Thriving", "Fair", "At Risk", "Lost", "Unchecked")}
    for t in trees:
        status_counts[t.status] += 1
    return {
        "records": len(trees),
        "planted": sum(t.quantity for t in trees),
        "checked_records": len(checked),
        "alive": alive,
        "planted_checked": planted_checked,
        "overall_rate": 100.0 * alive / planted_checked if planted_checked else None,
        "status_counts": status_counts,
        "by_species": group_stats(trees, lambda t: t.species),
        "by_location": group_stats(trees, lambda t: t.location),
        "monthly": monthly_planting(trees),
        "recent_90": recent,
        "prior_90": prior,
        "overdue": sum(1 for t in trees if t.next_check_due and t.next_check_due < today),
        "warnings": find_warnings(trees, today),
    }


def _pct(value: float | None) -> str:
    return "-" if value is None else f"{value:.1f}%"


def trends(s: dict) -> list[str]:
    lines = []
    rated = [r for r in s["by_species"] if r["rate"] is not None and r["planted"] >= 1]
    if len(rated) >= 2:
        best, worst = max(rated, key=lambda r: r["rate"]), min(rated, key=lambda r: r["rate"])
        lines.append(f"Best-performing species: {best['name']} ({_pct(best['rate'])}); "
                     f"weakest: {worst['name']} ({_pct(worst['rate'])}).")
    loc_rated = [r for r in s["by_location"] if r["rate"] is not None]
    if len(loc_rated) >= 2:
        worst_loc = min(loc_rated, key=lambda r: r["rate"])
        lines.append(f"Location needing most attention: {worst_loc['name']} ({_pct(worst_loc['rate'])} survival).")
    if s["recent_90"] or s["prior_90"]:
        if s["prior_90"]:
            change = 100.0 * (s["recent_90"] - s["prior_90"]) / s["prior_90"]
            lines.append(f"Planting pace: {s['recent_90']:,} saplings in the last 90 days vs "
                         f"{s['prior_90']:,} in the 90 before ({change:+.0f}%).")
        else:
            lines.append(f"Planting pace: {s['recent_90']:,} saplings in the last 90 days.")
    if s["overdue"]:
        lines.append(f"{s['overdue']} record(s) are overdue for a survival check (every {CHECK_INTERVAL_DAYS} days).")
    return lines or ["Not enough data for trends yet."]


def render_summary(trees: list[Tree], today: date) -> list[str]:
    """Plain-text (no colour) summary lines, shared by the console and Markdown/text exports."""
    s = summarize(trees, today)
    lines = [f"Records: {s['records']}    Saplings planted: {s['planted']:,}    "
             f"Records with a check: {s['checked_records']}/{s['records']}"]
    if s["overall_rate"] is not None:
        lines.append(f"Overall survival (checked records): {s['alive']:,} of {s['planted_checked']:,} "
                     f"= {s['overall_rate']:.1f}%")
    else:
        lines.append("Overall survival: no follow-up checks recorded yet.")
    lines += ["", "Status breakdown:"]
    top = max(s["status_counts"].values()) or 1
    for status, n in s["status_counts"].items():
        lines.append(f"  {status:<10} {n:>3}  {bar(n, top)}")

    def table(title: str, rows: list[dict], limit: int | None = None) -> None:
        lines.extend(["", title])
        shown = rows[:limit] if limit else rows
        body = [[r["name"], r["records"], f"{r['planted']:,}",
                 "-" if r["alive"] is None else f"{r['alive']:,}", _pct(r["rate"])] for r in shown]
        lines.extend(format_table(["Name", "Records", "Planted", "Alive", "Survival"], body, right_align={1, 2, 3, 4}))
        if limit and len(rows) > limit:
            lines.append(f"  ... and {len(rows) - limit} more")

    table("By species:", s["by_species"], limit=10)
    table("By location:", s["by_location"], limit=10)

    if s["monthly"]:
        lines.extend(["", "Planting by month (last 12 months with activity):"])
        recent = s["monthly"][-12:]
        peak = max(n for _, n in recent)
        for month, n in recent:
            lines.append(f"  {month}  {n:>6,}  {bar(n, peak, 24)}")

    lines.extend(["", "Key trends:"] + [f"  • {t}" for t in trends(s)])
    counts = {}
    for level, _, _ in s["warnings"]:
        counts[level] = counts.get(level, 0) + 1
    if counts:
        lines.append("  • Flags: " + ", ".join(f"{n} {lvl.lower()}" for lvl, n in counts.items()) + " (see Warnings)")
    return lines
