"""Report exports: Markdown summary, plain-text audit log, standardized CSV."""
from __future__ import annotations

import csv
import re
from datetime import date, datetime
from pathlib import Path

from analytics import find_warnings, render_summary
from models import Tree

_ANSI = re.compile(r"\033\[[0-9;]*m")

CSV_COLUMNS = ["tree_id", "species", "location", "planted_on", "quantity", "planted_by",
               "last_check_date", "surviving", "survival_pct", "status", "next_check_due", "notes"]


def _stamp() -> str:
    return datetime.now().strftime("%Y%m%d-%H%M%S")


def export_markdown(trees: list[Tree], out_dir: Path, today: date) -> Path:
    out_dir.mkdir(parents=True, exist_ok=True)
    path = out_dir / f"summary_{_stamp()}.md"
    body = _ANSI.sub("", "\n".join(render_summary(trees, today)))
    warnings = find_warnings(trees, today)
    lines = [f"# Tree Plantation Register - Summary", f"_Generated {today.isoformat()}_", "",
             "```text", body, "```", "", "## Warnings", ""]
    lines += [f"- **{lvl}** `{tid}`: {msg}" for lvl, tid, msg in warnings] or ["No warnings. 🌱"]
    lines += ["", "## Records", "",
              "| ID | Species | Location | Planted | Qty | Alive | Status | Next check |",
              "|---|---|---|---|---|---|---|---|"]
    for t in trees:
        alive = "-" if t.survivors is None else t.survivors
        due = t.next_check_due.isoformat() if t.next_check_due else "-"
        lines.append(f"| {t.tree_id} | {t.species} | {t.location} | {t.planted_on} | {t.quantity} | {alive} | {t.status} | {due} |")
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return path


def export_audit_log(trees: list[Tree], out_dir: Path, today: date) -> Path:
    out_dir.mkdir(parents=True, exist_ok=True)
    path = out_dir / f"audit_{_stamp()}.txt"
    lines = ["TREE PLANTATION REGISTER - AUDIT LOG", f"Generated: {datetime.now():%Y-%m-%d %H:%M:%S}",
             f"Records: {len(trees)}", "=" * 60]
    for t in trees:
        lines += ["", f"[{t.tree_id}] {t.species} x{t.quantity} - {t.location}",
                  f"  planted {t.planted_on} by {t.planted_by}; status: {t.status}"]
        if t.notes:
            lines.append(f"  notes: {t.notes}")
        for c in t.checks:
            extra = f" - {c.notes}" if c.notes else ""
            lines.append(f"  check {c.checked_on}: {c.surviving}/{t.quantity} alive{extra}")
        if not t.checks:
            lines.append("  (no follow-up checks recorded)")
    lines += ["", "=" * 60, "WARNINGS"]
    warnings = find_warnings(trees, today)
    lines += [f"  [{lvl}] {tid}: {msg}" for lvl, tid, msg in warnings] or ["  none"]
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return path


def export_csv(trees: list[Tree], out_dir: Path) -> Path:
    """Columns are a superset of what the importer reads, so exports can be re-imported."""
    out_dir.mkdir(parents=True, exist_ok=True)
    path = out_dir / f"trees_{_stamp()}.csv"
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=CSV_COLUMNS)
        writer.writeheader()
        for t in trees:
            last = t.latest_check
            writer.writerow({
                "tree_id": t.tree_id, "species": t.species, "location": t.location,
                "planted_on": t.planted_on.isoformat(), "quantity": t.quantity, "planted_by": t.planted_by,
                "last_check_date": last.checked_on.isoformat() if last else "",
                "surviving": last.surviving if last else "",
                "survival_pct": f"{t.survival_pct:.1f}" if t.survival_pct is not None else "",
                "status": t.status,
                "next_check_due": t.next_check_due.isoformat() if t.next_check_due else "",
                "notes": t.notes,
            })
    return path
