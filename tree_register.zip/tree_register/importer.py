"""Bulk CSV import with per-row validation and a row-by-row error log."""
from __future__ import annotations

import csv
from dataclasses import dataclass, field
from datetime import date, datetime
from pathlib import Path

from models import MAX_QUANTITY, Check, Tree
from storage import Store
from validation import clean_text, parse_date, parse_int

REQUIRED = ("species", "location", "planted_on", "quantity")
ALIASES = {"planted_date": "planted_on", "date": "planted_on", "qty": "quantity",
           "count": "quantity", "alive": "surviving", "last_check_surviving": "surviving",
           "last_checked": "last_check_date", "planter": "planted_by"}


@dataclass
class ImportResult:
    imported: int = 0
    skipped: int = 0
    errors: list[str] = field(default_factory=list)
    log_path: Path | None = None
    fatal: str | None = None


def _normalise_header(name: str) -> str:
    key = (name or "").strip().lower().replace(" ", "_")
    return ALIASES.get(key, key)


def _row_to_tree(row: dict, tree_id: str, today: date) -> Tree:
    """Validate one CSV row; raises ValueError listing the first problem found."""
    planted_on = parse_date(row.get("planted_on", ""), "planted_on", latest=today)
    quantity = parse_int(row.get("quantity", ""), "quantity", 1, MAX_QUANTITY)
    tree = Tree(
        tree_id=tree_id,
        species=clean_text(row.get("species", ""), "species", 2, 40).title(),
        location=clean_text(row.get("location", ""), "location", 2, 80),
        planted_on=planted_on,
        quantity=quantity,
        planted_by=clean_text(row.get("planted_by") or "Unknown", "planted_by", 1, 60),
        notes=clean_text(row.get("notes", ""), "notes", 0, 200),
    )
    check_date = (row.get("last_check_date") or "").strip()
    alive = (row.get("surviving") or "").strip()
    if check_date or alive:
        if not (check_date and alive):
            raise ValueError("last_check_date and surviving must be given together")
        tree.add_check(Check(
            checked_on=parse_date(check_date, "last_check_date", earliest=planted_on, latest=today),
            surviving=parse_int(alive, "surviving", 0, quantity),
        ))
    return tree


def import_csv(store: Store, csv_path: Path, log_dir: Path, today: date) -> ImportResult:
    result = ImportResult()
    try:
        handle = csv_path.open("r", newline="", encoding="utf-8-sig")
    except OSError as err:
        result.fatal = f"Cannot open file: {err.strerror or err}"
        return result

    with handle:
        try:
            reader = csv.DictReader(handle)
            if not reader.fieldnames:
                result.fatal = "File is empty or has no header row."
                return result
            reader.fieldnames = [_normalise_header(h) for h in reader.fieldnames]
            missing = [c for c in REQUIRED if c not in reader.fieldnames]
            if missing:
                result.fatal = f"Missing required column(s): {', '.join(missing)}"
                return result

            existing = {(t.species.casefold(), t.location.casefold(), t.planted_on, t.quantity) for t in store.trees}
            next_n = int(store.next_id()[1:])
            for line_no, row in enumerate(reader, start=2):      # line 1 is the header
                if None in row:                                    # more cells than headers
                    result.skipped += 1
                    result.errors.append(f"line {line_no}: too many columns")
                    continue
                if not any((v or "").strip() for v in row.values()):
                    continue                                       # silently ignore blank lines
                try:
                    tree = _row_to_tree(row, f"T{next_n:03d}", today)
                    key = (tree.species.casefold(), tree.location.casefold(), tree.planted_on, tree.quantity)
                    if key in existing:
                        raise ValueError("duplicate of an existing record")
                except ValueError as err:
                    result.skipped += 1
                    result.errors.append(f"line {line_no}: {err}")
                    continue
                existing.add(key)
                store.trees.append(tree)
                next_n += 1
                result.imported += 1
        except (csv.Error, UnicodeDecodeError) as err:
            result.fatal = f"File could not be parsed as CSV: {err}"
            if result.imported:
                store.save()
            return result

    if result.imported:
        store.save()
    if result.errors:
        log_dir.mkdir(parents=True, exist_ok=True)
        result.log_path = log_dir / f"import_errors_{datetime.now():%Y%m%d-%H%M%S}.log"
        header = [f"Import of {csv_path.name}: {result.imported} imported, {result.skipped} skipped", ""]
        result.log_path.write_text("\n".join(header + result.errors) + "\n", encoding="utf-8")
    return result
