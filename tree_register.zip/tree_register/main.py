#!/usr/bin/env python3
"""Tree Plantation Register - menu-driven terminal app.

Usage:  python main.py [--data-dir DIR]
"""
from __future__ import annotations

import argparse
import json
import sys
from datetime import date
from pathlib import Path

import analytics
import exports
import ui
from importer import import_csv
from models import MAX_QUANTITY, STATUSES, Check, Tree
from plots import ChartsUnavailable, make_charts
from storage import Store
from validation import (Cancelled, ask, ask_date, ask_int, ask_menu_choice, ask_text,
                        ask_yes_no)

APP_DIR = Path(__file__).resolve().parent
SAMPLE_JSON = APP_DIR / "sample_data" / "sample_trees.json"


class App:
    def __init__(self, data_dir: Path):
        self.data_dir = data_dir
        self.export_dir = data_dir / "exports"
        self.store = Store(data_dir / "trees.json")
        self.today = date.today()

    # ---- helpers ------------------------------------------------------------
    def tree_rows(self, trees: list[Tree]) -> list[list[object]]:
        rows = []
        for t in trees:
            pct = "-" if t.survival_pct is None else f"{t.survival_pct:.0f}%"
            due = t.next_check_due
            flag = " !" if due and due < self.today else ""
            rows.append([t.tree_id, t.species, t.location, t.planted_on, t.quantity,
                         "-" if t.survivors is None else t.survivors, pct, t.status,
                         (due.isoformat() if due else "-") + flag])
        return rows

    TREE_HEADERS = ["ID", "Species", "Location", "Planted", "Qty", "Alive", "Surv", "Status", "Next check"]

    def show_trees(self, trees: list[Tree]) -> None:
        if not trees:
            print(ui.yellow("No matching records."))
            return
        lines = ui.format_table(self.TREE_HEADERS, self.tree_rows(trees), max_width=24, right_align={4, 5, 6})
        ui.paginate(lines[2:], page_size=15, header=lines[:2])
        print(ui.dim(f"{len(trees)} record(s).  '!' = check overdue"))

    def resolve_tree(self, raw: str) -> Tree:
        text = raw.strip().upper()
        if text.isdigit():
            text = f"T{int(text):03d}"
        tree = self.store.get(text)
        if tree is None:
            raise ValueError(f"No record with ID '{raw}'. Use 'View all records' to see IDs.")
        return tree

    def pick_tree(self, prompt: str = "Tree ID (e.g. T012 or 12): ") -> Tree:
        return ask(prompt, self.resolve_tree)

    # ---- actions ------------------------------------------------------------
    def add_planting(self) -> None:
        ui.heading("Record a new planting")
        print(ui.dim("Type 'cancel' at any prompt to go back."))
        known = sorted({t.species for t in self.store.trees})
        if known:
            print(ui.dim("Known species: " + ", ".join(known[:12]) + (" ..." if len(known) > 12 else "")))
        species = ask_text("Species: ", "Species", 2, 40, transform=str.title)
        location = ask_text("Location (site / area): ", "Location", 2, 80)
        planted_on = ask_date("Planting date [YYYY-MM-DD, Enter = today]: ", "Planting date",
                              latest=self.today, default=self.today)
        quantity = ask_int(f"Saplings planted (1-{MAX_QUANTITY}): ", "Quantity", 1, MAX_QUANTITY)
        planted_by = ask_text("Planted by [Enter = Unknown]: ", "Planted by", 1, 60, default="Unknown")
        notes = ask_text("Notes (optional): ", "Notes", 0, 200, default="")
        tree = Tree(self.store.next_id(), species, location, planted_on, quantity, planted_by, notes)
        self.store.add(tree)
        print(ui.green(f"✓ Saved {tree.tree_id}: {quantity} x {species} at {location}."))
        print(ui.dim(f"  First survival check due {tree.next_check_due}."))

    def add_check(self) -> None:
        ui.heading("Log a follow-up survival check")
        if not self.store.trees:
            print(ui.yellow("No records yet - record a planting first."))
            return
        tree = self.pick_tree()
        if tree.status == "Lost":
            print(ui.yellow(f"{tree.tree_id} is already marked Lost (0 survivors). Nothing left to check."))
            return
        current = tree.survivors if tree.survivors is not None else tree.quantity
        earliest = max([tree.planted_on] + ([tree.latest_check.checked_on] if tree.latest_check else []))
        print(f"{tree.tree_id}: {tree.species} at {tree.location} - planted {tree.quantity}, "
              f"last known alive: {'unchecked' if tree.survivors is None else tree.survivors}.")
        checked_on = ask_date(f"Check date [YYYY-MM-DD, Enter = today]: ", "Check date",
                              earliest=earliest, latest=self.today, default=self.today)
        alive = ask_int(f"Saplings alive now (0-{current}): ", "Surviving count", 0, current)
        notes = ask_text("Notes (optional): ", "Notes", 0, 200, default="")
        tree.add_check(Check(checked_on, alive, notes))
        self.store.save()
        print(ui.green(f"✓ Check saved. Survival {tree.survival_pct:.0f}% - status: {tree.status}."))
        if tree.status in ("At Risk", "Lost"):
            print(ui.red("  ⚠ Survival is critical - consider replanting."))

    def list_all(self) -> None:
        ui.heading(f"All records ({len(self.store.trees)})")
        self.show_trees(self.store.trees)

    def search(self) -> None:
        ui.heading("Search & filter")
        print("  1) Keyword (any field, incl. notes)\n  2) By species\n  3) By location\n  4) By status\n  0) Back")
        choice = ask_menu_choice("Choose: ", {"0", "1", "2", "3", "4"})
        if choice == "0":
            return
        if choice == "1":
            kw = ask_text("Keyword: ", "Keyword", 1, 60)
            results = analytics.filter_trees(self.store.trees, keyword=kw)
        elif choice == "2":
            results = analytics.filter_trees(self.store.trees, species=ask_text("Species contains: ", "Species", 1, 40))
        elif choice == "3":
            results = analytics.filter_trees(self.store.trees, location=ask_text("Location contains: ", "Location", 1, 80))
        else:
            for i, s in enumerate(STATUSES, 1):
                print(f"  {i}) {s}")
            n = ask_int("Status number: ", "Status", 1, len(STATUSES))
            results = analytics.filter_trees(self.store.trees, status=STATUSES[n - 1])
        self.show_trees(results)

    def details(self) -> None:
        ui.heading("Record details")
        if not self.store.trees:
            print(ui.yellow("No records yet."))
            return
        t = self.pick_tree()
        print(f"\n{ui.bold(t.tree_id)}  {t.species} x{t.quantity}")
        print(f"  Location : {t.location}\n  Planted  : {t.planted_on} by {t.planted_by}")
        print(f"  Status   : {t.status}" + ("" if t.survival_pct is None else f" ({t.survival_pct:.1f}% alive)"))
        print(f"  Next due : {t.next_check_due or '-'}")
        if t.notes:
            print(f"  Notes    : {t.notes}")
        if t.checks:
            print("\n  Survival checks:")
            body = [[c.checked_on, c.surviving, f"{100 * c.surviving / t.quantity:.0f}%", c.notes] for c in t.checks]
            for line in ui.format_table(["Date", "Alive", "Surv", "Notes"], body, max_width=40, right_align={1, 2}):
                print("   " + line)
        else:
            print("\n  No follow-up checks yet.")
        for level, _, msg in (w for w in analytics.find_warnings([t], self.today)):
            print(ui.yellow(f"  ⚠ {level}: {msg}"))

    def summary(self) -> None:
        ui.heading(f"Executive summary - {self.today}")
        if not self.store.trees:
            print(ui.yellow("No records yet."))
            return
        for line in analytics.render_summary(self.store.trees, self.today):
            print(line)

    def warnings(self) -> None:
        ui.heading("Threshold warnings")
        found = analytics.find_warnings(self.store.trees, self.today)
        if not found:
            print(ui.green("✓ No warnings. Everything is on schedule."))
            return
        colour = {"CRITICAL": ui.red, "WARNING": ui.yellow, "ANOMALY": ui.cyan}
        lines = [f"{colour[lvl](f'{lvl:<8}')} {tid}  {msg}" for lvl, tid, msg in found]
        ui.paginate(lines, page_size=18)
        print(ui.dim(f"{len(found)} flag(s)."))

    def charts(self) -> None:
        ui.heading("Generate charts")
        if not self.store.trees:
            print(ui.yellow("No records to chart yet."))
            return
        try:
            paths = make_charts(self.store.trees, self.export_dir / "charts", self.today)
        except ChartsUnavailable as err:
            print(ui.red(f"Charts unavailable: {err}\nEverything else still works without it."))
            return
        print(ui.green("✓ Charts saved:"))
        for p in paths:
            print(f"   {p}")

    def export(self) -> None:
        ui.heading("Export reports")
        if not self.store.trees:
            print(ui.yellow("No records to export yet."))
            return
        print("  1) Markdown summary\n  2) Plain-text audit log\n  3) CSV report\n  4) All of the above\n  0) Back")
        choice = ask_menu_choice("Choose: ", {"0", "1", "2", "3", "4"})
        if choice == "0":
            return
        made = []
        if choice in ("1", "4"):
            made.append(exports.export_markdown(self.store.trees, self.export_dir, self.today))
        if choice in ("2", "4"):
            made.append(exports.export_audit_log(self.store.trees, self.export_dir, self.today))
        if choice in ("3", "4"):
            made.append(exports.export_csv(self.store.trees, self.export_dir))
        print(ui.green("✓ Exported:"))
        for p in made:
            print(f"   {p}")

    def import_file(self) -> None:
        ui.heading("Bulk import from CSV")
        print(ui.dim("Required columns: species, location, planted_on, quantity.\n"
                     "Optional: planted_by, notes, last_check_date + surviving."))
        raw = ask_text("Path to CSV file: ", "Path", 1, 300)
        result = import_csv(self.store, Path(raw).expanduser(), self.export_dir, self.today)
        if result.fatal:
            print(ui.red(f"✗ Import failed: {result.fatal}"))
            return
        print(ui.green(f"✓ Imported {result.imported} row(s).") + f" Skipped {result.skipped}.")
        for err in result.errors[:10]:
            print(ui.yellow(f"  - {err}"))
        if len(result.errors) > 10:
            print(ui.dim(f"  ... {len(result.errors) - 10} more in the log"))
        if result.log_path:
            print(f"Full error log: {result.log_path}")

    def delete(self) -> None:
        ui.heading("Delete a record")
        if not self.store.trees:
            print(ui.yellow("No records yet."))
            return
        t = self.pick_tree()
        if ask_yes_no(f"Permanently delete {t.tree_id} ({t.quantity} x {t.species}, {t.location})? [y/n]: "):
            self.store.remove(t.tree_id)
            print(ui.green(f"✓ Deleted {t.tree_id}."))
        else:
            print("Kept.")

    # ---- startup & loop -----------------------------------------------------
    def start(self) -> None:
        ui.banner()
        self.store.load()
        for note in self.store.load_notes:
            print(ui.yellow(f"ℹ {note}"))
        if not self.store.trees and SAMPLE_JSON.exists():
            try:
                if ask_yes_no("The register is empty. Load the sample dataset for a demo? [y/n]: ", default=False):
                    payload = json.loads(SAMPLE_JSON.read_text(encoding="utf-8"))
                    self.store.trees = [Tree.from_dict(r) for r in payload["trees"]]
                    self.store.save()
                    print(ui.green(f"✓ Loaded {len(self.store.trees)} sample records."))
            except (Cancelled, OSError, ValueError, KeyError, TypeError):
                print(ui.yellow("Skipped sample data."))
        count = len(self.store.trees)
        flags = analytics.find_warnings(self.store.trees, self.today)
        urgent = sum(1 for lvl, _, _ in flags if lvl in ("CRITICAL", "WARNING"))
        print(f"\n{count} record(s) loaded." + (ui.yellow(f"  ⚠ {urgent} need attention (option 7).") if urgent else ""))

    MENU = [("1", "Record a new planting", "add_planting"), ("2", "Log a follow-up survival check", "add_check"),
            ("3", "View all records", "list_all"), ("4", "Search & filter", "search"),
            ("5", "View record details", "details"), ("6", "Executive summary", "summary"),
            ("7", "Threshold warnings", "warnings"), ("8", "Generate charts (PNG)", "charts"),
            ("9", "Export reports (MD / TXT / CSV)", "export"), ("10", "Bulk import from CSV", "import_file"),
            ("11", "Delete a record", "delete"), ("0", "Save & exit", None)]

    def run(self) -> None:
        self.start()
        valid = {key for key, _, _ in self.MENU}
        while True:
            print()
            for key, label, _ in self.MENU:
                print(f"  {ui.bold(key.rjust(2))}  {label}")
            choice = ask_menu_choice("\nSelect an option: ", valid)
            if choice == "0":
                print(ui.green("All data saved. Happy planting! 🌱"))
                return
            handler = next(h for k, _, h in self.MENU if k == choice)
            try:
                getattr(self, handler)()
            except Cancelled:
                print(ui.yellow("Cancelled - nothing was changed."))
            except OSError as err:
                print(ui.red(f"File error: {err}. Your data in memory is unchanged; try again."))
            ui.pause()


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Tree Plantation Register")
    parser.add_argument("--data-dir", type=Path, default=APP_DIR / "data",
                        help="folder for trees.json and exports (default: ./data)")
    args = parser.parse_args(argv)
    app = App(args.data_dir)
    try:
        app.run()
    except (EOFError, KeyboardInterrupt):
        print("\nInput closed - exiting. Data is saved after every change.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
