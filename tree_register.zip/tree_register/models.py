"""Domain model: a Tree record (a planting batch) and its follow-up survival Checks."""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from datetime import date, timedelta

from validation import clean_text, parse_date, parse_int

# ---- Domain constants (tweak here) -------------------------------------------
MAX_QUANTITY = 1000          # saplings in one planting record
FIRST_CHECK_DAYS = 30        # first survival check is due this long after planting
CHECK_INTERVAL_DAYS = 90     # subsequent checks are due this often
THRIVING_PCT = 80.0          # >= this survival rate -> Thriving
AT_RISK_PCT = 50.0           # <  this survival rate -> At Risk

STATUSES = ("Thriving", "Fair", "At Risk", "Lost", "Unchecked")
_ID_RE = re.compile(r"^T\d{3,}$")


@dataclass
class Check:
    checked_on: date
    surviving: int
    notes: str = ""

    def to_dict(self) -> dict:
        return {"checked_on": self.checked_on.isoformat(), "surviving": self.surviving, "notes": self.notes}

    @classmethod
    def from_dict(cls, d: dict, quantity: int) -> "Check":
        return cls(
            checked_on=parse_date(d["checked_on"], "checked_on"),
            surviving=parse_int(d["surviving"], "surviving", 0, quantity),
            notes=clean_text(d.get("notes", ""), "notes", min_len=0, max_len=200),
        )


@dataclass
class Tree:
    tree_id: str
    species: str
    location: str
    planted_on: date
    quantity: int
    planted_by: str = "Unknown"
    notes: str = ""
    checks: list[Check] = field(default_factory=list)

    # ---- derived values -----------------------------------------------------
    @property
    def latest_check(self) -> Check | None:
        return self.checks[-1] if self.checks else None

    @property
    def survivors(self) -> int | None:
        """Surviving saplings per the latest check, or None if never checked."""
        return self.latest_check.surviving if self.latest_check else None

    @property
    def survival_pct(self) -> float | None:
        return None if self.survivors is None else 100.0 * self.survivors / self.quantity

    @property
    def status(self) -> str:
        pct = self.survival_pct
        if pct is None:
            return "Unchecked"
        if self.survivors == 0:
            return "Lost"
        if pct >= THRIVING_PCT:
            return "Thriving"
        if pct >= AT_RISK_PCT:
            return "Fair"
        return "At Risk"

    @property
    def next_check_due(self) -> date | None:
        """None once every sapling is lost (nothing left to monitor)."""
        if self.status == "Lost":
            return None
        if self.latest_check is None:
            return self.planted_on + timedelta(days=FIRST_CHECK_DAYS)
        return self.latest_check.checked_on + timedelta(days=CHECK_INTERVAL_DAYS)

    def add_check(self, check: Check) -> None:
        self.checks.append(check)
        self.checks.sort(key=lambda c: c.checked_on)

    # ---- (de)serialisation --------------------------------------------------
    def to_dict(self) -> dict:
        return {
            "tree_id": self.tree_id,
            "species": self.species,
            "location": self.location,
            "planted_on": self.planted_on.isoformat(),
            "quantity": self.quantity,
            "planted_by": self.planted_by,
            "notes": self.notes,
            "checks": [c.to_dict() for c in self.checks],
        }

    @classmethod
    def from_dict(cls, d: dict) -> "Tree":
        """Schema-check a stored record. Raises ValueError/KeyError/TypeError if invalid."""
        if not isinstance(d, dict):
            raise TypeError("record is not an object")
        tree_id = str(d["tree_id"]).strip().upper()
        if not _ID_RE.match(tree_id):
            raise ValueError(f"bad tree_id '{tree_id}'")
        quantity = parse_int(d["quantity"], "quantity", 1, MAX_QUANTITY)
        tree = cls(
            tree_id=tree_id,
            species=clean_text(d["species"], "species", 2, 40),
            location=clean_text(d["location"], "location", 2, 80),
            planted_on=parse_date(d["planted_on"], "planted_on"),
            quantity=quantity,
            planted_by=clean_text(d.get("planted_by") or "Unknown", "planted_by", 1, 60),
            notes=clean_text(d.get("notes", ""), "notes", 0, 200),
        )
        for raw in d.get("checks", []):
            tree.add_check(Check.from_dict(raw, quantity))
        return tree
