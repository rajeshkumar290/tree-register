"""Matplotlib charts. Matplotlib is imported lazily so the app still runs without it."""
from __future__ import annotations

from datetime import date
from pathlib import Path

from analytics import group_stats, monthly_planting
from models import AT_RISK_PCT, STATUSES, THRIVING_PCT, Tree

STATUS_COLORS = {"Thriving": "#1b7f5c", "Fair": "#e0a100", "At Risk": "#d95f02",
                 "Lost": "#8c2d04", "Unchecked": "#8a8f98"}
GREEN = "#2e7d4f"
INK = "#2b2f36"


class ChartsUnavailable(Exception):
    pass


def _pyplot():
    try:
        import matplotlib
        matplotlib.use("Agg")          # headless-safe: write files, never open windows
        import matplotlib.pyplot as plt
    except ImportError as err:
        raise ChartsUnavailable("matplotlib is not installed (pip install matplotlib).") from err
    plt.rcParams.update({"font.size": 10, "axes.spines.top": False, "axes.spines.right": False,
                         "axes.edgecolor": "#9aa0a6", "axes.labelcolor": INK, "text.color": INK,
                         "xtick.color": INK, "ytick.color": INK})
    return plt


def make_charts(trees: list[Tree], out_dir: Path, today: date) -> list[Path]:
    """Write three PNG charts and return their paths."""
    if not trees:
        raise ValueError("No records to chart yet.")
    plt = _pyplot()
    out_dir.mkdir(parents=True, exist_ok=True)
    paths = [_planting_trend(plt, trees, out_dir), _survival_by_species(plt, trees, out_dir),
             _status_distribution(plt, trees, out_dir, today)]
    return paths


def _planting_trend(plt, trees: list[Tree], out_dir: Path) -> Path:
    data = monthly_planting(trees)
    months = [m for m, _ in data]
    counts = [n for _, n in data]
    cumulative, running = [], 0
    for n in counts:
        running += n
        cumulative.append(running)

    fig, ax = plt.subplots(figsize=(9, 4.6))
    ax.bar(months, counts, color=GREEN, label="Saplings planted per month")
    ax.set_ylabel("Saplings planted")
    ax.set_title("Planting trend", loc="left", fontweight="bold")
    ax2 = ax.twinx()
    ax2.plot(months, cumulative, color=INK, marker="o", linewidth=1.8, label="Cumulative")
    ax2.set_ylabel("Cumulative saplings")
    ax2.spines["right"].set_visible(True)
    step = max(1, len(months) // 12)
    ax.set_xticks(range(0, len(months), step))
    ax.set_xticklabels(months[::step], rotation=45, ha="right")
    handles = ax.get_legend_handles_labels()[0] + ax2.get_legend_handles_labels()[0]
    labels = ax.get_legend_handles_labels()[1] + ax2.get_legend_handles_labels()[1]
    ax.legend(handles, labels, loc="upper left", frameon=False)
    fig.tight_layout()
    path = out_dir / "planting_trend.png"
    fig.savefig(path, dpi=150)
    plt.close(fig)
    return path


def _survival_by_species(plt, trees: list[Tree], out_dir: Path) -> Path:
    rows = [r for r in group_stats(trees, lambda t: t.species) if r["rate"] is not None]
    rows.sort(key=lambda r: r["rate"])
    fig, ax = plt.subplots(figsize=(9, max(3.2, 0.42 * len(rows) + 1.6)))
    if rows:
        colors = [STATUS_COLORS["Thriving"] if r["rate"] >= THRIVING_PCT
                  else STATUS_COLORS["Fair"] if r["rate"] >= AT_RISK_PCT else STATUS_COLORS["At Risk"]
                  for r in rows]
        ax.barh([r["name"] for r in rows], [r["rate"] for r in rows], color=colors)
        for i, r in enumerate(rows):
            ax.text(r["rate"] + 1, i, f"{r['rate']:.0f}%  (n={r['planted']:,})", va="center", fontsize=9)
        ax.axvline(THRIVING_PCT, color=INK, linestyle="--", linewidth=1)
        ax.axvline(AT_RISK_PCT, color=INK, linestyle=":", linewidth=1)
        ax.set_xlim(0, 118)
    else:
        ax.text(0.5, 0.5, "No survival checks recorded yet", ha="center", va="center", transform=ax.transAxes)
    ax.set_xlabel("Survival rate (%) — checked records only")
    ax.set_title("Survival by species", loc="left", fontweight="bold")
    fig.tight_layout()
    path = out_dir / "survival_by_species.png"
    fig.savefig(path, dpi=150)
    plt.close(fig)
    return path


def _status_distribution(plt, trees: list[Tree], out_dir: Path, today: date) -> Path:
    counts = {s: sum(1 for t in trees if t.status == s) for s in STATUSES}
    fig, ax = plt.subplots(figsize=(8, 4.2))
    bars = ax.bar(list(counts), list(counts.values()), color=[STATUS_COLORS[s] for s in counts])
    for rect, n in zip(bars, counts.values()):
        ax.text(rect.get_x() + rect.get_width() / 2, n + 0.15, str(n), ha="center", fontsize=10)
    ax.set_ylabel("Planting records")
    ax.set_title(f"Record status distribution (as of {today})", loc="left", fontweight="bold")
    fig.tight_layout()
    path = out_dir / "status_distribution.png"
    fig.savefig(path, dpi=150)
    plt.close(fig)
    return path
