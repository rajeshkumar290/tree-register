"""JSON persistence with schema checks, corruption recovery and atomic saves."""
from __future__ import annotations

import json
import os
import tempfile
from datetime import datetime
from pathlib import Path

from models import Tree

SCHEMA_VERSION = 1


class Store:
    def __init__(self, path: Path):
        self.path = Path(path)
        self.trees: list[Tree] = []
        self.load_notes: list[str] = []   # messages about recovery, shown at startup

    # ---- loading ------------------------------------------------------------
    def load(self) -> None:
        self.trees = []
        self.load_notes = []
        self.path.parent.mkdir(parents=True, exist_ok=True)

        try:
            text = self.path.read_text(encoding="utf-8")
            payload = json.loads(text)
        except FileNotFoundError:
            self.load_notes.append(f"No data file found - created a fresh register at {self.path}.")
            self.save()
            return
        except (json.JSONDecodeError, UnicodeDecodeError) as err:
            backup = self.path.with_name(f"{self.path.name}.corrupt-{datetime.now():%Y%m%d-%H%M%S}")
            self.path.rename(backup)
            self.load_notes.append(f"Data file was unreadable ({err}). Backed it up as {backup.name} and started fresh.")
            self.save()
            return

        records = payload.get("trees") if isinstance(payload, dict) else payload
        if not isinstance(records, list):
            backup = self.path.with_name(f"{self.path.name}.corrupt-{datetime.now():%Y%m%d-%H%M%S}")
            self.path.rename(backup)
            self.load_notes.append(f"Data file had an unexpected layout. Backed it up as {backup.name} and started fresh.")
            self.save()
            return

        seen: set[str] = set()
        for index, raw in enumerate(records, start=1):
            try:
                tree = Tree.from_dict(raw)
                if tree.tree_id in seen:
                    raise ValueError(f"duplicate id {tree.tree_id}")
            except (ValueError, KeyError, TypeError) as err:
                self.load_notes.append(f"Skipped stored record #{index}: {err}")
                continue
            seen.add(tree.tree_id)
            self.trees.append(tree)

    # ---- saving (atomic: write temp file, then replace) ----------------------
    def save(self) -> None:
        payload = {
            "schema_version": SCHEMA_VERSION,
            "saved_at": datetime.now().isoformat(timespec="seconds"),
            "trees": [t.to_dict() for t in self.trees],
        }
        self.path.parent.mkdir(parents=True, exist_ok=True)
        fd, tmp_name = tempfile.mkstemp(dir=self.path.parent, prefix=".trees-", suffix=".tmp")
        try:
            with os.fdopen(fd, "w", encoding="utf-8") as handle:
                json.dump(payload, handle, indent=2, ensure_ascii=False)
            os.replace(tmp_name, self.path)
        except BaseException:
            if os.path.exists(tmp_name):
                os.unlink(tmp_name)
            raise

    # ---- record helpers -----------------------------------------------------
    def next_id(self) -> str:
        highest = max((int(t.tree_id[1:]) for t in self.trees), default=0)
        return f"T{highest + 1:03d}"

    def get(self, tree_id: str) -> Tree | None:
        wanted = tree_id.strip().upper()
        return next((t for t in self.trees if t.tree_id == wanted), None)

    def add(self, tree: Tree) -> None:
        self.trees.append(tree)
        self.save()

    def remove(self, tree_id: str) -> bool:
        tree = self.get(tree_id)
        if tree is None:
            return False
        self.trees.remove(tree)
        self.save()
        return True
