"""Standard-library unit tests. Run from the project root:  python -m unittest discover -s tests -v"""
import sys
import tempfile
import unittest
from datetime import date, timedelta
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import analytics
from importer import import_csv
from models import Check, Tree
from storage import Store
from validation import clean_text, parse_date, parse_int

TODAY = date(2026, 11, 25)


def tree(n=1, qty=100, planted=TODAY - timedelta(days=100), alive=None, check_ago=10):
    t = Tree(f"T{n:03d}", "Neem", "North Lawn", planted, qty)
    if alive is not None:
        t.add_check(Check(TODAY - timedelta(days=check_ago), alive))
    return t


class ValidationTests(unittest.TestCase):
    def test_int_bounds(self):
        self.assertEqual(parse_int("1,000", "q", 1, 1000), 1000)
        for bad in ("0", "1001", "abc", "", "3.5"):
            with self.assertRaises(ValueError):
                parse_int(bad, "q", 1, 1000)

    def test_dates(self):
        self.assertEqual(parse_date("25/11/2026", "d"), TODAY)
        for bad in ("2026-02-31", "yesterday", ""):
            with self.assertRaises(ValueError):
                parse_date(bad, "d")
        with self.assertRaises(ValueError):
            parse_date("2027-01-01", "d", latest=TODAY)

    def test_text(self):
        self.assertEqual(clean_text("  Lake   Road ", "x"), "Lake Road")
        with self.assertRaises(ValueError):
            clean_text("a", "x")
        with self.assertRaises(ValueError):
            clean_text("x" * 100, "x", max_len=60)


class ModelTests(unittest.TestCase):
    def test_status_thresholds(self):
        self.assertEqual(tree().status, "Unchecked")
        self.assertEqual(tree(alive=80).status, "Thriving")     # boundary: exactly 80%
        self.assertEqual(tree(alive=79).status, "Fair")
        self.assertEqual(tree(alive=50).status, "Fair")         # boundary: exactly 50%
        self.assertEqual(tree(alive=49).status, "At Risk")
        self.assertEqual(tree(alive=0).status, "Lost")

    def test_next_check_due(self):
        t = tree()
        self.assertEqual(t.next_check_due, t.planted_on + timedelta(days=30))
        self.assertIsNone(tree(alive=0).next_check_due)

    def test_round_trip(self):
        t = tree(alive=70)
        self.assertEqual(Tree.from_dict(t.to_dict()), t)


class AnalyticsTests(unittest.TestCase):
    def test_warnings(self):
        trees = [tree(1, alive=40), tree(2, alive=0), tree(3), tree(4, alive=90, check_ago=120)]
        kinds = {(lvl, tid) for lvl, tid, _ in analytics.find_warnings(trees, TODAY)}
        self.assertIn(("CRITICAL", "T001"), kinds)
        self.assertIn(("CRITICAL", "T002"), kinds)
        self.assertIn(("WARNING", "T003"), kinds)    # never checked, 100 days old
        self.assertIn(("WARNING", "T004"), kinds)    # last check 120 days ago

    def test_anomaly_survivors_increase(self):
        t = tree(alive=10, check_ago=60)
        t.add_check(Check(TODAY - timedelta(days=5), 20))
        self.assertTrue(any(l == "ANOMALY" for l, _, _ in analytics.find_warnings([t], TODAY)))

    def test_summary_rate_ignores_unchecked(self):
        s = analytics.summarize([tree(1, qty=100, alive=50), tree(2, qty=900)], TODAY)
        self.assertAlmostEqual(s["overall_rate"], 50.0)
        self.assertEqual(s["planted"], 1000)

    def test_filter(self):
        a, b = tree(1, alive=90), tree(2, alive=10)
        self.assertEqual(analytics.filter_trees([a, b], status="At Risk"), [b])
        self.assertEqual(analytics.filter_trees([a, b], keyword="north"), [a, b])
        self.assertEqual(analytics.filter_trees([a, b], species="teak"), [])


class StorageAndImportTests(unittest.TestCase):
    def test_missing_and_corrupt_files(self):
        with tempfile.TemporaryDirectory() as d:
            path = Path(d) / "trees.json"
            store = Store(path)
            store.load()
            self.assertTrue(path.exists())
            path.write_text("{broken", encoding="utf-8")
            store.load()
            self.assertEqual(store.trees, [])
            self.assertEqual(len(list(Path(d).glob("trees.json.corrupt-*"))), 1)

    def test_save_load_and_ids(self):
        with tempfile.TemporaryDirectory() as d:
            store = Store(Path(d) / "trees.json")
            store.load()
            store.add(tree(1, alive=60))
            self.assertEqual(store.next_id(), "T002")
            again = Store(Path(d) / "trees.json")
            again.load()
            self.assertEqual(again.trees, store.trees)

    def test_import_logs_bad_rows(self):
        with tempfile.TemporaryDirectory() as d:
            csv_path = Path(d) / "in.csv"
            csv_path.write_text(
                "species,location,planted_date,qty\n"
                "Teak,Hill,2026-01-01,10\n"          # ok (aliased headers)
                "Teak,Hill,2026-01-01,10\n"          # duplicate
                "Neem,Hill,not-a-date,10\n"          # bad date
                "Neem,Hill,2026-01-01,-3\n", encoding="utf-8")   # bad quantity
            store = Store(Path(d) / "trees.json")
            store.load()
            result = import_csv(store, csv_path, Path(d), TODAY)
            self.assertEqual((result.imported, result.skipped), (1, 3))
            self.assertIsNotNone(result.log_path)
            self.assertIn("line 3: duplicate", result.errors[0])

    def test_import_missing_column(self):
        with tempfile.TemporaryDirectory() as d:
            csv_path = Path(d) / "in.csv"
            csv_path.write_text("species,location\nNeem,Hill\n", encoding="utf-8")
            store = Store(Path(d) / "trees.json")
            store.load()
            self.assertIn("Missing required", import_csv(store, csv_path, Path(d), TODAY).fatal)


if __name__ == "__main__":
    unittest.main()
