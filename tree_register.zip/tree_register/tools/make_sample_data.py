#!/usr/bin/env python3
"""Generate the sample datasets (JSON + CSV + a deliberately messy CSV).

Dates are generated relative to the day you run it, with a fixed random seed,
so the demo always shows a realistic mix of on-time, overdue and at-risk records.
Run from the project root:  python tools/make_sample_data.py
"""
import csv
import json
import random
import sys
from datetime import date, timedelta
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
from models import Check, Tree  # noqa: E402

TODAY = date.today()
rng = random.Random(46)

# species -> typical survival tendency (1.0 = hardy)
SPECIES = {"Neem": 0.93, "Peepal": 0.88, "Banyan": 0.85, "Mango": 0.78, "Gulmohar": 0.82,
           "Tamarind": 0.9, "Pongamia": 0.92, "Teak": 0.75, "Jamun": 0.8, "Arjuna": 0.7,
           "Ashoka": 0.6, "Indian Rosewood": 0.55}
LOCATIONS = ["North Campus Lawn", "Science Block Garden", "Lake Road Avenue", "Hostel Quad",
             "Sports Ground Edge", "Community Park Sector 4", "Nursery Plot A", "Riverside Bund"]
PLANTERS = ["NSS Volunteers", "Green Club", "Eco Society", "Rotary Youth", "Staff Team", "Class of 2026"]


def make_tree(n: int, days_ago: int, species: str, location: str, qty: int,
              checks: list[tuple[int, float]], note: str = "") -> Tree:
    """checks: list of (days_ago, survival_fraction); fractions must not increase."""
    planted = TODAY - timedelta(days=days_ago)
    tree = Tree(f"T{n:03d}", species, location, planted, qty, rng.choice(PLANTERS), note)
    last = qty
    for d_ago, frac in checks:
        alive = min(last, max(0, round(qty * frac)))
        tree.add_check(Check(TODAY - timedelta(days=d_ago), alive,
                             rng.choice(["", "", "Watered and mulched", "Some leaf drop", "Looking healthy", "Fenced"])))
        last = alive
    return tree


trees: list[Tree] = []
n = 1
# ~34 "normal" records spread over the last ~14 months
for _ in range(34):
    species = rng.choice(list(SPECIES))
    base = SPECIES[species]
    days_ago = rng.randint(20, 420)
    qty = rng.choice([10, 15, 20, 25, 30, 40, 50, 60, 80, 100, 150, 200])
    checks, frac = [], 1.0
    t = days_ago - 30
    while t > 0 and len(checks) < 4:
        frac = max(0.0, frac * min(1.0, base + rng.uniform(0.02, 0.12)))
        checks.append((t, frac))
        t -= rng.choice([60, 90, 120])     # some intervals exceed 90 days -> overdue flags
    trees.append(make_tree(n, days_ago, species, rng.choice(LOCATIONS), qty, checks,
                           rng.choice(["", "", "", "Drip irrigation installed", "Near water pipeline"])))
    n += 1

# ---- hand-made boundary / edge cases -------------------------------------------
edge = [
    # boundary: smallest batch, planted today, never checked (not yet due)
    make_tree(n, 0, "Neem", "Nursery Plot A", 1, [], "Boundary: minimum quantity, planted today"),
    # boundary: largest batch (also triggers the large-batch anomaly flag)
    make_tree(n + 1, 200, "Pongamia", "Riverside Bund", 1000, [(120, 0.9), (30, 0.86)], "Boundary: maximum quantity"),
    # 100% survival
    make_tree(n + 2, 60, "Banyan", "Hostel Quad", 12, [(20, 1.0)], "Perfect survival"),
    # total loss
    make_tree(n + 3, 150, "Indian Rosewood", "Sports Ground Edge", 25, [(110, 0.4), (40, 0.0)], "Edge: all saplings lost (drought)"),
    # never checked, planted long ago -> overdue first check
    make_tree(n + 4, 240, "Mango", "Lake Road Avenue", 40, [], "Edge: never followed up"),
    # at-risk (<50%)
    make_tree(n + 5, 300, "Ashoka", "Community Park Sector 4", 80, [(200, 0.7), (60, 0.38)], "Edge: low survival, replant advised"),
]
trees.extend(edge)
n += len(edge)
# anomaly: survivors increase between checks (data-entry mistake) - written directly, bypassing validation
anomaly = make_tree(n, 180, "Jamun", "North Campus Lawn", 30, [(120, 0.5)], "Anomaly: count rose on 2nd check")
anomaly.checks.append(Check(TODAY - timedelta(days=40), 24, "Recount - maybe miscounted earlier"))
trees.append(anomaly)

assert 30 <= len(trees) <= 50, len(trees)
out_dir = ROOT / "sample_data"
out_dir.mkdir(exist_ok=True)

# JSON: full store format (what the app loads)
(out_dir / "sample_trees.json").write_text(
    json.dumps({"schema_version": 1, "trees": [t.to_dict() for t in trees]}, indent=2), encoding="utf-8")

# CSV: importer-compatible, latest check only
with (out_dir / "sample_trees.csv").open("w", newline="", encoding="utf-8") as fh:
    w = csv.writer(fh)
    w.writerow(["species", "location", "planted_on", "quantity", "planted_by", "last_check_date", "surviving", "notes"])
    for t in trees:
        last = t.latest_check
        w.writerow([t.species, t.location, t.planted_on, t.quantity, t.planted_by,
                    last.checked_on if last else "", last.surviving if last else "", t.notes])

# Legacy CSV with deliberate errors, to demo the row-by-row error log
bad_rows = [
    ["species", "location", "planted_on", "quantity", "planted_by", "last_check_date", "surviving", "notes"],
    ["Neem", "Old Orchard", (TODAY - timedelta(days=90)).isoformat(), "50", "Legacy Team", (TODAY - timedelta(days=30)).isoformat(), "45", "OK row"],
    ["", "Old Orchard", (TODAY - timedelta(days=80)).isoformat(), "20", "", "", "", "blank species"],
    ["Teak", "Old Orchard", "31/02/2026", "20", "", "", "", "impossible date"],
    ["Mango", "Old Orchard", (TODAY - timedelta(days=70)).isoformat(), "twelve", "", "", "", "non-numeric quantity"],
    ["Jamun", "Old Orchard", (TODAY - timedelta(days=60)).isoformat(), "0", "", "", "", "quantity below minimum"],
    ["Banyan", "Old Orchard", (TODAY + timedelta(days=30)).isoformat(), "10", "", "", "", "planted in the future"],
    ["Arjuna", "Old Orchard", (TODAY - timedelta(days=100)).isoformat(), "30", "", (TODAY - timedelta(days=20)).isoformat(), "35", "survivors exceed planted"],
    ["Peepal", "Old Orchard", (TODAY - timedelta(days=50)).isoformat(), "15", "", (TODAY - timedelta(days=10)).isoformat(), "", "check date without count"],
    ["Gulmohar", "Old Orchard", (TODAY - timedelta(days=45)).isoformat(), "1,000", "Legacy Team", "", "", "OK row (thousands separator)"],
]
with (out_dir / "legacy_with_errors.csv").open("w", newline="", encoding="utf-8") as fh:
    csv.writer(fh).writerows(bad_rows)

print(f"Wrote {len(trees)} records to {out_dir}/ (sample_trees.json, sample_trees.csv, legacy_with_errors.csv)")
