"""Terminal presentation helpers: ANSI colour, banner, fixed-width tables, pagination."""
from __future__ import annotations

import os
import sys

USE_COLOR = sys.stdout.isatty() and not os.environ.get("NO_COLOR")


def _wrap(code: str, text: str) -> str:
    return f"\033[{code}m{text}\033[0m" if USE_COLOR else text


def bold(t: str) -> str: return _wrap("1", t)
def dim(t: str) -> str: return _wrap("2", t)
def green(t: str) -> str: return _wrap("32", t)
def yellow(t: str) -> str: return _wrap("33", t)
def red(t: str) -> str: return _wrap("31", t)
def cyan(t: str) -> str: return _wrap("36", t)


def banner() -> None:
    line = "═" * 52
    print(green(line))
    print(green("  🌳  TREE PLANTATION REGISTER"))
    print(dim("  Record plantings · locations · survival checks"))
    print(green(line))


def heading(title: str) -> None:
    print()
    print(bold(cyan(f"── {title} " + "─" * max(4, 48 - len(title)))))


def truncate(text: str, width: int) -> str:
    return text if len(text) <= width else text[: max(1, width - 1)] + "…"


def format_table(headers: list[str], rows: list[list[object]],
                 max_width: int = 28, right_align: set[int] | None = None) -> list[str]:
    """Fixed-width table with column separators. Returns a list of lines."""
    right_align = right_align or set()
    cells = [[truncate(str(c), max_width) for c in row] for row in rows]
    widths = [len(h) for h in headers]
    for row in cells:
        for i, c in enumerate(row):
            widths[i] = max(widths[i], len(c))

    def fmt(row: list[str]) -> str:
        parts = [c.rjust(widths[i]) if i in right_align else c.ljust(widths[i])
                 for i, c in enumerate(row)]
        return " │ ".join(parts)

    sep = "─┼─".join("─" * w for w in widths)
    return [bold(fmt(headers)), sep] + [fmt(r) for r in cells]


def paginate(lines: list[str], page_size: int = 15, header: list[str] | None = None) -> None:
    """Print lines in pages; Enter = next page, q = stop. Header repeats on every page."""
    if not lines:
        return
    for start in range(0, len(lines), page_size):
        if header:
            print("\n".join(header))
        print("\n".join(lines[start:start + page_size]))
        end = start + page_size
        if end < len(lines):
            try:
                answer = input(dim(f"-- {min(end, len(lines))}/{len(lines)} shown · Enter = next page, q = stop -- "))
            except EOFError:
                return
            if answer.strip().lower() == "q":
                return


def pause() -> None:
    try:
        input(dim("\nPress Enter to continue..."))
    except EOFError:
        pass


def bar(value: float, maximum: float, width: int = 20) -> str:
    if maximum <= 0:
        return ""
    return "█" * max(0, round(width * value / maximum))
