"""Input validation: pure parsers (reused by the CSV importer) and
interactive prompt wrappers that loop until the user gives a valid answer.

Every prompt accepts the word "cancel" to abort back to the menu.
"""
from __future__ import annotations

from datetime import date, datetime
from typing import Callable, TypeVar

T = TypeVar("T")

DATE_FORMATS = ("%Y-%m-%d", "%d-%m-%Y", "%d/%m/%Y")


class Cancelled(Exception):
    """Raised when the user types 'cancel' at any prompt."""


# --------------------------------------------------------------------------
# Pure parsers: raise ValueError with a human-readable message
# --------------------------------------------------------------------------
def clean_text(value: object, field: str, min_len: int = 2, max_len: int = 60) -> str:
    text = " ".join(str(value if value is not None else "").split())
    if len(text) < min_len:
        raise ValueError(
            f"{field} is required." if min_len == 1 else f"{field} must be at least {min_len} characters."
        )
    if len(text) > max_len:
        raise ValueError(f"{field} must be at most {max_len} characters (got {len(text)}).")
    if not text.isprintable():
        raise ValueError(f"{field} contains control characters.")
    return text


def parse_int(value: object, field: str, lo: int, hi: int) -> int:
    raw = str(value).strip().replace(",", "")
    if not raw:
        raise ValueError(f"{field} is required.")
    try:
        number = int(raw)
    except ValueError:
        raise ValueError(f"{field} must be a whole number (got '{value}').") from None
    if not lo <= number <= hi:
        raise ValueError(f"{field} must be between {lo} and {hi} (got {number}).")
    return number


def parse_date(
    value: object,
    field: str,
    earliest: date | None = None,
    latest: date | None = None,
) -> date:
    raw = str(value).strip()
    if not raw:
        raise ValueError(f"{field} is required.")
    parsed = None
    for fmt in DATE_FORMATS:
        try:
            parsed = datetime.strptime(raw, fmt).date()
            break
        except ValueError:
            continue
    if parsed is None:
        raise ValueError(f"{field} must look like YYYY-MM-DD (got '{value}').")
    if earliest and parsed < earliest:
        raise ValueError(f"{field} cannot be before {earliest.isoformat()}.")
    if latest and parsed > latest:
        raise ValueError(f"{field} cannot be after {latest.isoformat()}.")
    return parsed


# --------------------------------------------------------------------------
# Interactive wrappers
# --------------------------------------------------------------------------
def ask(prompt: str, parser: Callable[[str], T], default: T | None = None) -> T:
    """Prompt until `parser` accepts the input. Blank input returns `default` if given."""
    while True:
        raw = input(prompt).strip()
        if raw.lower() == "cancel":
            raise Cancelled
        if raw == "" and default is not None:
            return default
        try:
            return parser(raw)
        except ValueError as err:
            print(f"  ✗ {err}  (type 'cancel' to abort)")


def ask_text(prompt: str, field: str, min_len: int = 2, max_len: int = 60,
             default: str | None = None, transform: Callable[[str], str] | None = None) -> str:
    def parser(raw: str) -> str:
        text = clean_text(raw, field, min_len, max_len)
        return transform(text) if transform else text
    return ask(prompt, parser, default)


def ask_int(prompt: str, field: str, lo: int, hi: int) -> int:
    return ask(prompt, lambda raw: parse_int(raw, field, lo, hi))


def ask_date(prompt: str, field: str, earliest: date | None = None,
             latest: date | None = None, default: date | None = None) -> date:
    return ask(prompt, lambda raw: parse_date(raw, field, earliest, latest), default)


def ask_yes_no(prompt: str, default: bool | None = None) -> bool:
    def parser(raw: str) -> bool:
        low = raw.lower()
        if low in ("y", "yes"):
            return True
        if low in ("n", "no"):
            return False
        raise ValueError("Please answer y or n.")
    return ask(prompt, parser, default)


def ask_menu_choice(prompt: str, valid: set[str]) -> str:
    """Menu selection; returns the chosen key (never raises Cancelled)."""
    while True:
        raw = input(prompt).strip().lower()
        if raw in valid:
            return raw
        print(f"  ✗ Please choose one of: {', '.join(sorted(valid, key=lambda s: (len(s), s)))}")
